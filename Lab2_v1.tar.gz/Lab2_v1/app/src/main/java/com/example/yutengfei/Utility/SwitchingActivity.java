package com.example.yutengfei.Utility;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.app.FragmentManager;
import android.app.Fragment;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import com.example.yutengfei.lab2_v1_MainAdmins.FragmentAdminsUserEditPhoto;
import com.example.yutengfei.lab2_v1_MainAdmins.FragmentListNormalInput;

/**
 * Created by yutengfei on 14/04/16.
 */
public class SwitchingActivity extends Activity {

    static public final String TITLE ="Title";
    static  public final  String DEFAULT ="Default";
    static public final String HINT ="Hint";

    static public final String ACTION = "Action";
    static public final String TAKE_PHOTO = "TakePhoto";
    static public final String LIST_POSITION = "ItemsPosition";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE) {
            // If the screen is now in landscape mode, we can show the
            // dialog in-line with the list so we don't need this activity.
            finish();
            return;
        }



        int flag = 1;
        Intent intent = getIntent();

        int ItemsPosition = intent.getIntExtra(LIST_POSITION, -1);
        if(ItemsPosition == -1) {
            Log.d("SwitchingActivity", "Not ItemsPosition:" + ItemsPosition);
            flag =1;
        }else{
            Log.d("SwitchingActivity", "ItemsPosition :" + ItemsPosition);
            flag=0;
            this.switching2fragment();
        }


        if(flag == 1) {
            Bundle switchingKey = intent.getExtras();
            switch (switchingKey.getString(ACTION)) {
                case (TAKE_PHOTO):
                    this.switching2photo(savedInstanceState);
                    break;
                default:
                    Log.d("SwitchingActivity", "No Mach Action");
                    break;

            }
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


    }

    public void switching2photo(Bundle savedInstanceState){

        Log.d("SwitchingAction", "Photo Action");
        if (savedInstanceState == null) {
            FragmentAdminsUserEditPhoto editPhoto = new FragmentAdminsUserEditPhoto();
            editPhoto.setArguments(getIntent().getExtras());
            FragmentManager fm = getFragmentManager();

            /*Using extras intent to select ...*/
            fm.beginTransaction().add(android.R.id.content, editPhoto).commit();

        }else{
            Log.d("SwitchingActiong","Not PhotoAction");
        }



    }

    public void switching2fragment(){

        FragmentListNormalInput listInput = new FragmentListNormalInput();
        listInput.setArguments(getIntent().getExtras());
        FragmentManager fm = getFragmentManager();
            /*Using extras intent to select ...*/
        fm.beginTransaction().add(android.R.id.content, listInput).commit();
    }
}

