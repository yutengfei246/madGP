package com.example.yutengfei.Utility;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import com.example.yutengfei.lab2_v1.MainMenu;
import com.example.yutengfei.lab2_v1.R;
import com.example.yutengfei.lab2_v1_MainAdmins.MainAdmins;
import com.example.yutengfei.lab2_v1_MainAdmins.MainRP.MainRP;

/**
 * Created by yutengfei on 13/04/16.
 */
public class SelectEvents {

    private View.OnClickListener view;

    static public SelectEvents getInstance(){
        return  new SelectEvents();
    }


    public SelectEvents(View.OnClickListener view){
            this.view = view;
    }

    public SelectEvents(){}

    public void selectEvents(Context context,View view){


            int id = view.getId();

            switch (id){
                case R.id.toolbar_bottom_menu:
                    this.startActivity(context, MainMenu.class, true);
                    break;
                case R.id.toolbar_bottom_comments:
                    Toast.makeText(context,"comments item",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.toolbar_bottom_manager:
                    this.startActivity(context,MainAdmins.class,true);
                    break;
                case R.id.toolbar_bottom_order:
                    Toast.makeText(context,"order item",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.toolbar_menu_menu_image:
                    Toast.makeText(context,"menu menu",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.toolbar_menu_deals_image:
                    Toast.makeText(context,"menu deals",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.toolbar_menu_plate_image:
                    Toast.makeText(context,"menu plate",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.toolbar_menu_offer_image:
                    Toast.makeText(context,"menu offer",Toast.LENGTH_SHORT).show();
                    break;
                case R.id.toolbar_admin_user_image:
                    Toast.makeText(context," admins user",Toast.LENGTH_SHORT).show();
                    this.startActivity(context,MainAdmins.class,true);
                    break;
                case R.id.toolbar_admin_RP_image:
                    Toast.makeText(context,"admins RP",Toast.LENGTH_SHORT).show();
                    this.startActivity(context, MainRP.class,true);
                    break;
                default:
                    Toast.makeText(context,"default Item",Toast.LENGTH_SHORT).show();
                    break;
            }

        return;




    }



    public void startActivity(Context context,Class theClass, boolean finish){

        Intent intent = new Intent(context,theClass);
        Activity activity = (Activity)context;
        activity.startActivity(intent);
        if(finish)
            activity.finish();



    }
}
