package com.example.yutengfei.lab2_v1;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.sql.Date;
import java.util.List;

/**
 * Created by yutengfei on 13/04/16.
 */
public class OperListAdapter<T> extends ArrayAdapter<T> {

    private T DataHolder ;
    private int resourceItem ;
    private List<T> ListData;
    viewHolder vHolder = new viewHolder();


    private static class viewHolder{
        ImageView iv;
        TextView tv;
    }

    public OperListAdapter(Context context, int resource, List<T> objects) {
        super(context, resource, objects);
        this.resourceItem = resource;
        this.ListData = objects;
    }

    @Override
    public T getItem(int position){

        return ListData.get(position);
    }




    @Override
    public View getView(int position, View convertView ,ViewGroup parent){

        if(convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(this.resourceItem, parent, false);

        }




        if( this.ListData.get(position) instanceof  OperDataContiner ) {

            vHolder.iv = (ImageView)convertView.findViewById(R.id.fragment_ope_item_image);
            vHolder.tv = (TextView)convertView.findViewById(R.id.framgment_ope_item_middle_text);

            OperDataContiner Data;

            Data = (OperDataContiner) getItem(position);
            vHolder.iv.setImageResource(Data.getIcon());
            vHolder.tv.setText(Data.getTitle());
        }

        if(this.ListData.get(position) instanceof  String ){

            String str = (String)getItem(position);
            TextView tv = (TextView)convertView.findViewById(R.id.fragment_admins_user_profiles);
            tv.setText(str);

        }

            return convertView;


    }

}

