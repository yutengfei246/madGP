package com.example.yutengfei.lab2_v1;

import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yutengfei.Utility.SelectEvents;


public class MainMenu extends AppCompatActivity implements OperationFragment.OnFragmentInteractionListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);


        setSupportActionBar((Toolbar) this.getToolbar());
        this.setDarkColor((ImageView) findViewById(R.id.toolbar_bottom_menu));
        this.setTextColor((TextView) findViewById(R.id.toolbar_bottom_menu_text));

        this.setDarkColorTop((ImageView) findViewById(R.id.toolbar_menu_menu_image));
        this.setTextColorTop((TextView)findViewById(R.id.toolbar_menu_menu_text));


        this.setViewListener((View) findViewById(R.id.toolbar_menu_menu_image));
        this.setViewListener((View) findViewById(R.id.toolbar_menu_plate_image));
        this.setViewListener((View) findViewById(R.id.toolbar_menu_deals_image));
        this.setViewListener((View) findViewById(R.id.toolbar_menu_offer_image));


        //this.setViewListener((View) findViewById(R.id.toolbar_bottom_menu));
        this.setViewListener((View) findViewById(R.id.toolbar_bottom_comments));
        this.setViewListener((View)findViewById(R.id.toolbar_bottom_manager));
        this.setViewListener((View)findViewById(R.id.toolbar_bottom_order));




    }

    @Override
    public void onFragmentInteraction(Uri uri){

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        int id = item.getItemId();

        switch (id){
            case (R.id.toolbar_bottom_menu):
                Toast.makeText(getApplicationContext(),item.getTitle(), Toast.LENGTH_SHORT).show();
                break;


        }

        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main_menu_items, menu);
        return true;
    }



    /* Used Methods */
    public Toolbar getToolbar(){
        return (Toolbar)findViewById(R.id.toolbar);
    }

    public Toolbar getToolbarBottom(){return (Toolbar)findViewById(R.id.toolbar_bottom);}


    public void setViewListener(View view){
        view.setOnClickListener(new View.OnClickListener(){

            @Override
        public void onClick(View view){
                view.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.click_anim));
                SelectEvents.getInstance().selectEvents(MainMenu.this, view);

                /*Question why here*/
                /*
                Intent intent = new Intent(getApplicationContext(),MainAdmins.class);
                startActivity(intent);
                finish();
*/
            }
        });
    }

    public void setDarkColor(ImageView view){

        view.setImageResource(R.drawable.cutlery_dark);

    }

    public void setTextColor(TextView tv){

        tv.setTextColor(ContextCompat.getColor(MainMenu.this, R.color.colorDarkBlue));
    }


    public void setDarkColorTop(ImageView view){

        view.setImageResource(R.drawable.cutlery_pur);

    }

    public void setTextColorTop(TextView tv){

        tv.setTextColor(ContextCompat.getColor(this, R.color.colorDarKRed));
    }

}
