package com.example.yutengfei.lab2_v1_MainAdmins;

import android.app.ListFragment;

/**
 * Created by yutengfei on 15/04/16.
 */
public class FragmentListUserInfo extends ListFragment {


}
