package com.example.yutengfei.lab2_v1_MainAdmins;

import android.content.Intent;
import android.net.Uri;
import android.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yutengfei.lab2_v1.R;
import com.example.yutengfei.Utility.SelectEvents;
import com.example.yutengfei.Utility.SwitchingActivity;

import org.w3c.dom.Text;

public class MainAdmins extends AppCompatActivity implements FragmentAdminsUserPhoto.OnFragmentInteractionListener ,
                                            FragmentAdminsUserProfile. OnListFragmentInteractionListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_admins);

        this.setAdminsListeners();
        this.setTextColor((TextView) findViewById(R.id.toolbar_bottom_admins_text));
        this.setDarkColor((ImageView) findViewById(R.id.toolbar_bottom_manager));
        this.setDarkColorTop((ImageView) findViewById(R.id.toolbar_admin_user_image));
        this.setTextColorTop((TextView)findViewById(R.id.toolbar_admin_user_text));

    }


    public void setViewListener(View view){
        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                view.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.click_anim));
                SelectEvents.getInstance().selectEvents(MainAdmins.this, view);

            }
        });
    }

    public void setDarkColor(ImageView view){

        view.setImageResource(R.drawable.people_dark);

    }

    public void setTextColor(TextView tv){

        tv.setTextColor(ContextCompat.getColor(MainAdmins.this, R.color.colorDarkBlue));
    }

    /*Communication with Fragments in FragmentsAdminsUserPhotos*/
    @Override
    public void onFragmentInteraction(Uri uri) {


            Toast.makeText(this,"pressed",Toast.LENGTH_SHORT).show();

            /*Show the Fragment that for edit*/

            FragmentManager fm = getFragmentManager();


            if(uri.equals(Uri.parse("StartActivityForFragment"))){
                /*start new activity for showing fragment*/

                Intent intent = new Intent(this,SwitchingActivity.class);
                Bundle switchingKey = new Bundle();
                switchingKey.putString(SwitchingActivity.ACTION,SwitchingActivity.TAKE_PHOTO);

                intent.putExtras(switchingKey);
                startActivity(intent);

        }else {
                /*showing the fragement just in the room*/
            }


    }


    public void setAdminsListeners(){


        this.setViewListener((View) findViewById(R.id.toolbar_admin_about_image));
        this.setViewListener((View) findViewById(R.id.toolbar_admin_RP_image));
        this.setViewListener((View) findViewById(R.id.toolbar_admin_user_image));
        this.setViewListener((View) findViewById(R.id.toolbar_admin_SA_image));


        this.setViewListener((View) findViewById(R.id.toolbar_bottom_menu));
        this.setViewListener((View) findViewById(R.id.toolbar_bottom_comments));
        //this.setViewListener((View) findViewById(R.id.toolbar_bottom_manager));
        this.setViewListener((View) findViewById(R.id.toolbar_bottom_order));

    }

    public void setDarkColorTop(ImageView view){

        view.setImageResource(R.drawable.people_pur);

    }

    public void setTextColorTop(TextView tv){

        tv.setTextColor(ContextCompat.getColor(MainAdmins.this, R.color.colorDarKRed));
    }


    public void OnListFragmentInteractionListener(Uri uri){

    }
}
