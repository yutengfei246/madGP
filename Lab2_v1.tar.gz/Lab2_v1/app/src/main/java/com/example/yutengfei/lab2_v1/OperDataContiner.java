package com.example.yutengfei.lab2_v1;

import android.graphics.drawable.Drawable;

/**
 * Created by yutengfei on 13/04/16.
 */
public class OperDataContiner {

    private  int icon;
    private  String title ;

    public OperDataContiner(){}

    public OperDataContiner(int drawable , String str){
        this.icon = drawable;
        this.title = str;

    }

    public void setIcon(int icon){
        this.icon = icon;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public int getIcon() {
        return icon;
    }

    public String getTitle(){
        return title;
    }

    public static OperDataContiner getInstance(){
        return new OperDataContiner();
    }
    public static OperDataContiner getInstance(int drawable, String str) {
        return new OperDataContiner(drawable,str);
    }

}
