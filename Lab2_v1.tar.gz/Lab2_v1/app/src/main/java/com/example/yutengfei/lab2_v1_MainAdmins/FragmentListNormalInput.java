package com.example.yutengfei.lab2_v1_MainAdmins;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.yutengfei.lab2_v1.R;

/**
 * Created by yutengfei on 15/04/16.
 */
public class FragmentListNormalInput extends Fragment {

    private String title = "Default";
    private String hint = "Default :";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_admin_normal_input, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        this.setBackListener((ImageView) getActivity().findViewById(R.id.toolbar_back_back));
        this.setDoneListener((TextView)getActivity().findViewById(R.id.toolbar_back_done));

        Bundle bundle;
        bundle = getArguments();

        if(bundle == null) {


            this.setTxt((TextView)getActivity().findViewById(R.id.toolbar_back_title),this.title);
            this.setTxt((TextView)getActivity().findViewById(R.id.fragment_normal_input_edit_data),this.hint);
            }else{


            this.setTxt((TextView)getActivity().findViewById(R.id.toolbar_back_title),bundle.getString("Title"));
            this.setTxt((TextView)getActivity().findViewById(R.id.fragment_normal_input_edit_data),bundle.getString("Hint"));
        }
        }



    public void setBackListener(ImageView iv){
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /*Here to store everything*/
                v.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.click_anim));
                getActivity().finish();
            }
        });



    }

    public void setTxt(TextView v, String str){

        v.setText(str);
    }

    public void setDoneListener(TextView tv){

        /*set listener here*/
        tv.setOnClickListener( new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                /*Store EditText contents and finish the SwitchingActivity  */


                v.startAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.click_anim));
                getActivity().finish();
            }
        });

    }


}
