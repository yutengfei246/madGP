package com.example.yutengfei.lab2_v1_MainAdmins.MainRP;

import android.app.Fragment;
import android.app.ListFragment;
import android.content.Intent;
import android.os.Bundle;
import java.util.*;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.yutengfei.Utility.SwitchingActivity;
import com.example.yutengfei.lab2_v1.OperListAdapter;
import com.example.yutengfei.lab2_v1.R;

/**
 * Created by yutengfei on 15/04/16.
 */
public class FragmentRPinfo extends ListFragment{

    private List<String> myData;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.d("FragmentRPinfo","Fragment created");
        this.myData = new ArrayList<String>();
        /*initial myData*/

        this.myData.add("Rest&Pub Name ");
        this.myData.add("Location ");
        this.myData.add("Picture");
        this.myData.add("Fax");
        this.myData.add("Working Email");
        this.myData.add("Working Cell ");
        this.myData.add("Working Status");;
        this.myData.add("Net Web");
        this.myData.add("Description");
        this.myData.add("History");


        Log.d("FragmentRPinfo", "Before Set Adapter");
        setListAdapter(new OperListAdapter<String>(getActivity(), R.layout.fragment_fragment_admins_user_profile, this.myData));
        Log.d("FragmentRpinfo", "After Set Adapter");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d("FragmentRp", "Create View");
        View view =inflater.inflate(R.layout.fragment_operation, container, false);
        Log.d("FragmentRp","After Create View");

        return view;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        String item = this.myData.get(position);
        v.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.click_anim));
        Toast.makeText(getActivity(), item, Toast.LENGTH_SHORT).show();
        Bundle extras = new Bundle();
        extras.putString(SwitchingActivity.TITLE,item);
        extras.putString(SwitchingActivity.HINT, SwitchingActivity.DEFAULT);
        Intent intent = new Intent(getActivity(),SwitchingActivity.class);

        intent.putExtra(SwitchingActivity.LIST_POSITION,position);
        intent.putExtras(extras);
        startActivity(intent);

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        Log.d("FragmentRp", "Acvivity Created");
        getListView().setDivider(null);

    }
}
