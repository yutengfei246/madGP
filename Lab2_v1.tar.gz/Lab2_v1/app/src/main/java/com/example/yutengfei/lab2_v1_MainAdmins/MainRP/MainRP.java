package com.example.yutengfei.lab2_v1_MainAdmins.MainRP;

import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.yutengfei.Utility.SelectEvents;
import com.example.yutengfei.lab2_v1.R;

/**
 * Created by yutengfei on 15/04/16.
 */
public class MainRP extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rp);

        this.setAdminsListeners();
        this.setTextColor((TextView) findViewById(R.id.toolbar_bottom_admins_text));
        this.setDarkColor((ImageView) findViewById(R.id.toolbar_bottom_manager));
        this.setDarkColorTop((ImageView) findViewById(R.id.toolbar_admin_RP_image));
        this.setTextColorTop((TextView)findViewById(R.id.toolbar_admin_RP_text));
    }

    public void setAdminsListeners(){

        this.setViewListener((View) findViewById(R.id.toolbar_admin_about_image));
       // this.setViewListener((View) findViewById(R.id.toolbar_admin_RP_image));
        this.setViewListener((View) findViewById(R.id.toolbar_admin_user_image));
        this.setViewListener((View) findViewById(R.id.toolbar_admin_SA_image));


        this.setViewListener((View) findViewById(R.id.toolbar_bottom_menu));
        this.setViewListener((View) findViewById(R.id.toolbar_bottom_comments));
        //this.setViewListener((View) findViewById(R.id.toolbar_bottom_manager));
        this.setViewListener((View) findViewById(R.id.toolbar_bottom_order));

    }

    public void setViewListener(View view){
        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                view.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.click_anim));
                SelectEvents.getInstance().selectEvents(MainRP.this, view);

            }
        });
    }

    public void setDarkColorTop(ImageView view){

        view.setImageResource(R.drawable.buildings_pur);

    }

    public void setTextColorTop(TextView tv){

        tv.setTextColor(ContextCompat.getColor(MainRP.this, R.color.colorDarKRed));
    }

    public void setDarkColor(ImageView view){

        view.setImageResource(R.drawable.people_dark);

    }

    public void setTextColor(TextView tv){

        tv.setTextColor(ContextCompat.getColor(MainRP.this, R.color.colorDarkBlue));
    }

}
